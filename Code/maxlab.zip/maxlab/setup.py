from setuptools import setup, find_packages
from os import path

here = path.abspath(path.dirname(__file__))

with open(path.join(here, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='maxlab',
    version='0.0.1',
    description='Maxlab Python utilities',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='MaxLab',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: MaxWell',
        'Programming Language :: Python :: 3',
        'License :: MIT'
    ],
    packages=find_packages(exclude=()),
    install_requires=['numpy', 'scipy', 'requests'],
    include_package_data=True)